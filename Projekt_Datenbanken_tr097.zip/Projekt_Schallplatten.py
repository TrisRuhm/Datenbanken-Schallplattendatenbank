#!C:\Program Files\Python38\python.exe
import json
from tinydb import TinyDB, Query
from tinydb.operations import delete
import streamlit as st
import pandas as pd
import datetime
import re
from functools import reduce

print("Content-type: text/html")
print()

db = TinyDB("schallplatten_db.json")
table_object = db.table("vinyl_table")

tab1, tab2, tab3 = st.tabs(["Titelsuche", "Eintrag anlegen", "Alle Titel"])

with st.sidebar:
    st.title("Vinyl_DB")
    formats = ['Album', 'Single']
    val = [None] * len(formats)
    for i, form in enumerate(formats):
        val[i] = st.checkbox(form, value=True, key=f'format_query_{i}')
    format_query = [formats[i] for i, selected in enumerate(val) if selected]
    # Orientierung: https://stackoverflow.com/questions/74243710/how-can-we-create-this-type-of-filter-checkbox-in-streamlit-python
    genres = ['Rock', 'Pop', 'Jazz', 'Hiphop', 'Metal', 'RocknRoll', 'Schlager', 'Klassik', 'Indie']
    genre_query = st.multiselect('Genre:', genres, [], key='genre_query')

with tab1:
    with st.form(key='search_form'):
        st.text_input("Suche", key="item")
        st.form_submit_button(label="Suchen")
    filtered_query = []
    vinyl = Query()
    if st.session_state.item:
        item_query = st.session_state.item
        filtered_query.append((vinyl.title.matches(item_query, flags=re.IGNORECASE)) | (
            vinyl.artist.matches(item_query, flags=re.IGNORECASE)) | (vinyl.tracks.any(
            item_query)))  # re.IGNORECASE nicht möglich bei tracks, da in einer Liste nach dem zutreffenden Track gesucht wird
    if genre_query:
        filtered_query.append(vinyl.genre.any(genre_query))
    if format_query:
        filtered_query.append(vinyl.vinyl_type.one_of(format_query))
    vinyl_query = table_object.search(
        reduce(lambda a, b: a & b, filtered_query)) if filtered_query else table_object.all()
    # reduce und lambda:
    # https://tinydb.readthedocs.io/en/latest/usage.html#query-modifiers
    # https://stackoverflow.com/questions/8689184/nameerror-name-reduce-is-not-defined-in-python
    if vinyl_query != '':
        st.write("Die Datenbank hat ", str(len(vinyl_query)), " Vinyl(s) gefunden")
        for result in vinyl_query:
            col1, col2, col3 = st.columns([2, 2, 2])
            vinyl_id = result.doc_id
            with col1:
                if result['cover'] != "":
                    st.image(result["cover"], width=200)
                else:
                    st.write("No Image")
                with st.expander("Tracks"):
                    for track in result["tracks"]:
                        st.write(track)
            with col2:
                st.header(result["title"])
                st.write("Format:", result["vinyl_type"])
                st.write("Künstler: ", result["artist"])
                st.write("Label: ", result["publisher"])
                st.write(
                    f'Genre: {", ".join(result["genre"])}')
                # Orientierung: https://stackoverflow.com/questions/62250996/using-print-joinmy-array-to-extract-individual-strings-and-adding-it-to
                st.write("Release: ", result["release_date"])
                st.write("Katalog-Nr.: ", result["Katalog-Nr."])
            with col3:
                # mit dem Expander wird ein Feld zur Bearbeitung des verwendet
                with st.expander("Bearbeiten"):
                    update_title = st.text_input('Title', value=result["title"], key="title" + str(vinyl_id))
                    update_artist = st.text_input('Artist', value=result["artist"],
                                                  key="artist" + str(vinyl_id))
                    update_date = st.date_input('Release',
                                                key="date" + str(vinyl_id))
                    update_type = st.text_input('Type', value=result["vinyl_type"], key="type" + str(vinyl_id))
                    genres = ['Rock', 'Pop', 'Jazz', 'Hiphop', 'Metal', 'RocknRoll', 'Schlager', 'Klassik', 'Indie']
                    update_genre = st.multiselect('Genre:', genres, default=result["genre"],
                                                  key="genre" + str(vinyl_id))
                    update_publisher = st.text_input('Publisher', value=result["publisher"],
                                                     key="publisher" + str(vinyl_id))
                    update_cataloge = st.text_input('Katalog-Nr.', value=result["Katalog-Nr."],
                                                    key="cataloge" + str(vinyl_id))
                    update_cover = st.text_input("Cover (URL)", value=result["cover"],
                                                 key="cover" + str(vinyl_id))
                    if 'n_rows_update' not in st.session_state:
                        st.session_state.n_rows_update = 0
                    update_tracks = []
                    for track in result['tracks']:
                        if track:
                            update_track = st.text_input("Track", value=track, key='update_' + str(track))
                        update_tracks.append(update_track)
                    for i in range(st.session_state.n_rows_update):
                        new_track = st.text_input("Track" + str(i),
                                                  key=result["title"] + '_update_track_' + str(i))
                    # mit Klick auf Button-"Track hinzufügen" wird ein Suchfeld hinzugefügt
                    if st.button(label="Track hinzugefügen", key="update_track" + result["title"]):
                        st.session_state.n_rows_update += 1
                        st.experimental_rerun()
                    # mit Klick auf Button-"Track entfernen" wird ein Suchfeld entfernt
                    if st.button(label="Track entfernen", key="del_track" + result["title"]):
                        st.session_state.n_rows_update -= 1
                        st.experimental_rerun()
                    if st.button("Update", key="update" + str(vinyl_id)):
                        # alle neuen Tracks werden in die Liste update_track getan
                        for i in range(st.session_state.n_rows_update):
                            update_tracks.append(new_track)

                        updated_data = {"title": update_title, "artist": update_artist,
                                        "release_date": update_date.strftime("%Y-%m-%d"),
                                        "genre": update_genre,
                                        "vinyl_type": update_type,
                                        "publisher": update_publisher, "Katalog-Nr.": update_cataloge,
                                        "cover": update_cover,
                                        "tracks": update_tracks}
                        table_object.update(updated_data, vinyl.title == result["title"])

                        st.write("Update successful")
                        for key in st.session_state.keys():
                            del st.session_state[key]
                        st.experimental_rerun()
                with st.expander("Eintrag löschen"):
                    st.write("Soll der Eintrag wirklich gelöscht werden?")
                    if st.button('Ja', key="delete" + str(vinyl_id)):
                        delete_dataset = table_object.remove(doc_id=vinyl_id)
                        delete_dataset
                        if delete_dataset:
                            st.write("Eintrag wurde gelöscht.")
                        else:
                            st.write("Eintrag konnte nicht gelöscht werden")
            st.write('------')
    else:
        # Ausgabe, wenn keine Einträge gefunden wurden.
        st.write("Keine Einträge gefunden")
with tab2:
    form_entry = st.form('form_entry')
    form_entry.header("Neuer Eintrag")
    form_entry.text_input("Titel", key="new_title"),
    form_entry.text_input("Künstler", key="new_artist"),
    form_entry.text_input("Format", key="new_type"),
    form_entry.date_input("Release-Datum", key="new_date")
    genres = ['Rock', 'Pop', 'Jazz', 'Hiphop', 'Metal', 'RocknRoll', 'Schlager', 'Klassik']
    form_entry.multiselect("Genre", genres, [], key="new_genre")
    form_entry.text_input("Label", key="new_publisher"),
    form_entry.text_input("Katalog-Nr.", key="new_cataloge"),
    form_entry.text_input("Cover (URL)", key="new_cover"),

    if 'n_rows' not in st.session_state:
        st.session_state.n_rows = 0

    for i in range(st.session_state.n_rows):
        form_entry.text_input("Track" + str(i), key="new_track" + str(i))
    # bei streamlit können keine zusätzlichen buttons in eine Form eingefügt werden;
    # es wäre auch möglich einen neuen Eintrag über die Inputfelder ohne der Anwendung von Form
    # da allerdings die form_entry nötig ist, um den neuen Datensatz einheitlich in die JSON-File zu implementieren,
    # habe ich mich dazu entschieden dies anzuwenden. Daher sind die Buttons zum hinzufügen/entfernen neuer Track-Inputfelder nicht richtig formatiert
    if st.button(label="Track hinzufügen", key="new_track"):
        st.session_state.n_rows += 1
        st.experimental_rerun()

    if st.button(label="Track entfernen", key="del_track"):
        st.session_state.n_rows -= 1
        st.experimental_rerun()

    form_entry.form_submit_button(label="Eintrag anlegen")
    # Orientierung anhand des Codes: https://stackoverflow.com/questions/70120608/how-to-add-new-text-inputs-row-by-row-on-clicking-a-button-in-streamlit
    if st.session_state.new_title:

        new_title = st.session_state.new_title
        new_artist = st.session_state.new_artist
        new_type = st.session_state.new_type
        new_date = st.session_state.new_date
        new_genre = st.session_state.new_genre
        new_publisher = st.session_state.new_publisher
        new_cataloge = st.session_state.new_cataloge
        new_cover = st.session_state.new_cover
        new_tracks = []
        for i in range(st.session_state.n_rows):
            new_tracks.append(st.session_state["new_track" + str(i)])

        table_object.insert(
            {"title": new_title, "artist": new_artist, "release_date": new_date.strftime("%Y-%m-%d"),
             "genre": new_genre,
             "vinyl_type": str(new_type), "publisher": new_publisher, "Katalog-Nr.": new_cataloge,
             "cover": new_cover, "tracks": new_tracks})

        for key in st.session_state.keys():
            del st.session_state[key]
        st.experimental_rerun()

with tab3:
    # Dient zur Übersicht der einzelnen Datensätze
    st.table(table_object)
