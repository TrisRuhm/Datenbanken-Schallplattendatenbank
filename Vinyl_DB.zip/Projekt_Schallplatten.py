#!C:\Program Files\Python38\python.exe
import json
from tinydb import TinyDB, Query
from tinydb.operations import delete
import streamlit as st
import pandas as pd
import datetime

print("Content-type: text/html")
print()

db = TinyDB("schallplatten_db.json")
table_object = db.table("vinyl_table")

# Benutzerdefiniertes Theme
custom_theme = """
[theme]
primaryColor = '#00FF00'
"""
st.set_page_config(page_title='Vinyl_DB', layout='wide', initial_sidebar_state='expanded')

tab1, tab2, tab3 = st.tabs(["Titelsuche", "Eintrag anlegen", "Alle Titel"])  #
# st.date_input("Suche nach Datum", key="date")
with st.sidebar:
    st.title("Vinyl_DB")
    query_form = st.form("query_form")
    query_form.text_input("Suche", key="item")
    query_form.form_submit_button(label="Suchen")
    st.header("Genre")
    genres = ['Rock', 'Pop', 'Jazz', 'Hiphop', 'Metal', 'RocknRoll', 'Schlager', 'Klassik', 'Indie']
    st.multiselect("", genres, [])

with tab1:
    if st.session_state.item:
        item_query = st.session_state.item
        vinyl_query = table_object.search(
            (Query().title == item_query) | (Query().artist == item_query) | (Query().vinyl_type == item_query))
        if not vinyl_query:  # Ausgabe, wenn keine Einträge gefunden wurden.
            st.write("Keine Einträge gefunden")
        else:  # Ausgabe, wenn Einträge gefunden wurden.
            st.write("Die Datenbank hat ", len(vinyl_query), " Einträge gefunden")
            for result in vinyl_query:
                col1, col2, col3 = st.columns([1, 2, 1])
                vinyl_id = result.doc_id
                with col1:
                    st.image(result["cover"], width=200)

                with col2:
                    st.header(result["title"])
                    st.write("Format:", result["vinyl_type"])
                    st.write("Künstler: ", result["artist"])
                    st.write("Label: ", result["publisher"])
                    st.write("Genre: ", result["genre"][0])
                    st.write("Release: ", result["release_date"])
                    st.write("ISBN: ", result["ISBN"])
                    with st.expander("Tracks"):
                        for track in result["tracks"]:
                            st.write(track)
                with col3:
                    with st.expander("Bearbeiten"):
                        update_title = st.text_input('Title', value=result["title"], key="title"+str(vinyl_id))
                        update_artist = st.text_input('Artist', value=result["artist"], key="artist"+str(vinyl_id))
                        update_date = st.date_input('Release',
                                                    value=datetime.datetime.strptime(result["release_date"],
                                                                                     "%Y-%m-%d").date(), min_value=datetime.date(1800, 1, 1), key="date"+str(vinyl_id))
                        update_type = st.text_input('Type', value=result["vinyl_type"], key="type"+str(vinyl_id))
                        update_publisher = st.text_input('Publisher', value=result["publisher"], key="publisher"+str(vinyl_id))
                        update_isbn = st.text_input('ISBN', value=result["ISBN"], key="isbn"+str(vinyl_id))
                        update_cover = st.text_input("Cover (URL)", key="cover"+str(vinyl_id))

                        if 'n_rows_update' not in st.session_state:
                            st.session_state.n_rows_update = 1

                            add = st.button(label="Neuer Track", key="update")

                            if add:
                                st.session_state.n_rows_update += 1
                                st.experimental_rerun()

                            for i in range(st.session_state.n_rows_update):
                                # add text inputs here
                                st.text_input("Track" + str(i), key=i)  # Pass index as key

                        if st.button("Update", key="update" + str(vinyl_id)):
                            update_tracks = []
                            for i in range(st.session_state.n_rows_update):
                                update_tracks.append(st.session_state[i])
                            updated_data = {"title": update_title, "artist": update_artist,
                                            "release_date": update_date.strftime("%Y-%m-%d"), "vinyl_type": update_type,
                                            "publisher": update_publisher, "ISBN": update_isbn, "cover": update_cover,
                                            "tracks": update_tracks}
                            table_object.update(updated_data, Query().title == result["title"])

                            st.write("Update successful")

                    with st.expander("Eintrag löschen"):
                        st.write("Soll der Eintrag wirklich gelöscht werden?")
                        if st.button('Ja', key="delete" + str(vinyl_id)):
                            delete_dataset = table_object.remove(doc_id=vinyl_id)
                            delete_dataset
                            if delete_dataset:
                                st.write("Eintrag wurde gelöscht.")
                            else:
                                st.write("Eintrag konnte nicht gelöscht werden")
                st.write("------------")

with tab2:
    form = st.form("new_entry_form")
    form.header("Neuer Eintrag")

    form.text_input("Titel", key="new_title"),
    form.text_input("Künstler", key="new_artist"),
    form.text_input("Typ", key="new_type"),
    form.date_input("Release-Datum", key="new_date", min_value=datetime.date(1800, 1, 1)),
    genres = ['Rock', 'Pop', 'Jazz', 'Hiphop', 'Metal', 'RocknRoll', 'Schlager', 'Klassik']
    form.multiselect("", genres, [], key="new_genre")
    form.text_input("Label", key="new_publisher"),
    form.text_input("ISBN", key="new_isbn"),
    form.text_input("Cover (URL)", key="new_cover"),
    form.write("-------")
    if 'n_rows' not in st.session_state:
        st.session_state.n_rows = 1

    add = st.button(label="Neuer Track", key="new_track")

    if add:
        st.session_state.n_rows += 1
        st.experimental_rerun()

    for i in range(st.session_state.n_rows):
        # add text inputs here
        form.text_input("Track" + str(i), key="new_track"+str(i))
        # Orientierung anhand des Codes: https://stackoverflow.com/questions/70120608/how-to-add-new-text-inputs-row-by-row-on-clicking-a-button-in-streamlit
    form.form_submit_button(label="Submit")

    if st.session_state.new_title:

        new_title = st.session_state.new_title
        new_artist = st.session_state.new_artist
        new_date = st.session_state.new_date
        new_genre = st.session_state.new_genre
        new_type = st.session_state.new_type
        new_publisher = st.session_state.new_publisher
        new_isbn = st.session_state.new_isbn
        new_cover = st.session_state.new_cover
        new_tracks = []
        for i in range(st.session_state.n_rows):
            new_tracks.append(st.session_state[str(new_title)+str(i)])

        table_object.insert({"title": new_title, "artist": new_artist, "release_date": new_date.strftime("%Y-%m-%d"),
                             "genre": new_genre,
                             "vinyl_type": str(new_type), "publisher": new_publisher, "ISBN": new_isbn,
                             "cover": new_cover, "tracks": new_tracks})
        st.empty()

with tab3:
    st.table(table_object)
